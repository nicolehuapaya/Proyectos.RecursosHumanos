# Encuesta de Clima Laboral – Trimestral

Objetivo: Recoger percepciones de los colaboradores sobre clima, comunicación, liderazgo y bienestar.

Secciones sugeridas:
1. Comunicación (claridad, feedback, canales).
2. Bienestar (carga laboral, estrés, salud mental).
3. Liderazgo (apoyo, confianza, motivación).
4. Reconocimiento (valoración de logros).
5. Desarrollo (oportunidades de capacitación).
6. Cultura (trabajo en equipo, sentido de pertenencia).

Escala de respuesta: Likert (1 = Totalmente en desacuerdo, 5 = Totalmente de acuerdo).
