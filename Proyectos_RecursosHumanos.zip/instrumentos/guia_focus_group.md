# Guía para Focus Group – Experiencia del Empleado

Objetivo: Profundizar en percepciones de clima laboral, motivación y cultura.

Pasos:
1. Bienvenida y explicación del propósito.
2. Preguntas guía:
   - ¿Qué aspectos valoras más de trabajar aquí?
   - ¿Qué mejorarías para sentirte más motivado/a?
   - ¿Cómo percibes la comunicación interna?
   - ¿Qué iniciativas de bienestar serían más útiles?
   - ¿Qué esperas del reconocimiento y desarrollo profesional?
3. Registro de hallazgos.
4. Conclusiones y agradecimientos.
