# Formato de Feedback Continuo

Colaborador:  
Fecha:  
Área:  

Estructura de Feedback (Modelo STAR):
- Situación:  
- Tarea:  
- Acción:  
- Resultado:  

Observaciones adicionales:  
Próximos pasos/acuerdos:
