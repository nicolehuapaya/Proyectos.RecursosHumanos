# Reporte de KPIs – Trimestral

Indicadores:
- Clima laboral: ___%
- Engagement: ___%
- Rotación voluntaria: ___%
- Productividad: ___%
- Formación: ___%

Análisis de variación respecto al trimestre anterior:
