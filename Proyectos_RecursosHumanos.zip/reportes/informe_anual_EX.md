# Informe Anual – Experiencia del Empleado

Contenido sugerido:
1. Resumen ejecutivo
2. Metodología
3. Resultados principales (KPIs)
4. Buenas prácticas identificadas
5. Áreas de mejora
6. Recomendaciones para el siguiente año
