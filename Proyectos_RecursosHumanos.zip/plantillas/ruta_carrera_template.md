# Ruta de Carrera – [Nombre del Puesto]

Objetivo: Establecer pasos claros para el crecimiento profesional.

Etapas:
1. Posición inicial: competencias y requisitos.
2. Siguientes niveles: puestos a los que puede ascender.
3. Competencias requeridas en cada nivel.
4. Programas de capacitación sugeridos.
5. Indicadores de avance.
